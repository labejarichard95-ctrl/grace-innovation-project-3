let products=[],cart=JSON.parse(localStorage.getItem('gip_cart')||'[]');
const fmt=n=>'UGX '+Number(n).toLocaleString();
async function api(url,opt={}){const r=await fetch(url,{headers:{'Content-Type':'application/json',...(opt.headers||{})},...opt});const d=await r.json();if(!r.ok)throw Error(d.error||'Request failed');return d}
function render(){const el=document.querySelector('#product-list');if(!el)return;el.innerHTML=products.map(p=>`<article class="card product"><div class="product-img">${p.image?`<img src="${p.image}" alt="${p.name}">`:'<span>🧼</span>'}</div><h3>${p.name}</h3><p>${p.description||''}</p><strong>${fmt(p.price)} / ${p.unit}</strong><button class="btn primary small" onclick="add(${p.id})">Add to order</button></article>`).join('')||'<p>No products have been added yet.</p>';document.querySelector('#cart-count').textContent=cart.reduce((n,i)=>n+i.qty,0)}
function add(id){const x=cart.find(i=>i.id===id);if(x)x.qty++;else cart.push({id,qty:1});localStorage.setItem('gip_cart',JSON.stringify(cart));render();alert('Added to your order.');}
async function init(){products=await api('/api/products');render();const me=await api('/api/me');document.querySelector('#account-state').innerHTML=me.user?`Logged in as <b>${me.user.full_name}</b> · <button onclick="logout()">Log out</button>`:'<a href="account.html">Create account / Log in</a>'}
async function logout(){await api('/api/logout',{method:'POST'});location.reload()}
window.add=add;window.logout=logout;init();
