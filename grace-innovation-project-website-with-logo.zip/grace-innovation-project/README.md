# GRACE INNOVATION PROJECT Website

Official website: GRACEINNOVATIONPROJECT.COM

The site includes the business homepage, products and prices, customer registration/login, online ordering, mobile-money payment instructions, free delivery for bulk orders of 5 boxes or more, admin controls, and order email notification configuration.

The official GIP logo is included as `logo.png` and is displayed on the homepage, customer account page, and admin login page.

## Contact
- Call/WhatsApp: 0789 897 524
- Call/WhatsApp: 0771 451 337
- Mobile Money registered name: LABEJA RICHARD
- Email: graceinnovationproject@gmail.com
- Location: Lalogi Trading Center, Omoro District, Uganda
