const express=require('express');
const session=require('express-session');
const bcrypt=require('bcryptjs');
const Database=require('better-sqlite3');
const multer=require('multer');
const path=require('path');
const fs=require('fs');
const nodemailer=require('nodemailer');
const app=express();
const PORT=process.env.PORT||3000;
const ADMIN_USER=process.env.ADMIN_USER||'admin';
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'CHANGE_THIS_ADMIN_PASSWORD';
const NOTIFY_EMAIL=process.env.NOTIFY_EMAIL||'graceinnovationproject@gmail.com';
const transporter=(process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASS)
 ? nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}})
 : null;
async function notifyNewOrder(order){
  if(!transporter) return;
  const subject=`New order #${order.id} - GRACE INNOVATION PROJECT`;
  const text=`New website order #${order.id}

Customer: ${order.customer_name}
Contact: ${order.contact}
Delivery location: ${order.location}
Total: UGX ${Number(order.total).toLocaleString()}
Payment method: Mobile Money
Payment reference: ${order.payment_reference || 'Not provided'}
Free delivery: ${order.free_delivery ? 'Yes (5+ boxes)' : 'No'}

Items:
${order.items.map(i=>`- ${i.name} x ${i.qty} @ UGX ${Number(i.price).toLocaleString()}`).join('\n')}

Please log in to the admin dashboard to review and update this order.`;
  await transporter.sendMail({from:process.env.SMTP_FROM||process.env.SMTP_USER,to:NOTIFY_EMAIL,subject,text});
}

const db=new Database(path.join(__dirname,'data.db'));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,full_name TEXT NOT NULL,location TEXT NOT NULL,contact TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,description TEXT,price INTEGER NOT NULL,unit TEXT DEFAULT 'item',image TEXT,active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,customer_name TEXT NOT NULL,contact TEXT NOT NULL,location TEXT NOT NULL,total INTEGER NOT NULL,status TEXT DEFAULT 'Pending',payment_method TEXT DEFAULT 'Mobile Money',payment_reference TEXT,items_json TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));`);
const productCount=db.prepare('SELECT COUNT(*) c FROM products').get().c; if(productCount===0){const add=db.prepare('INSERT INTO products(name,description,price,unit) VALUES(?,?,?,?)'); add.run('Bar Soap – 600g','25 bars per box (15kg total).',68000,'box'); add.run('Bar Soap – 1kg','10 bars per box (10kg total).',45000,'box');}
const uploadDir=path.join(__dirname,'uploads'); if(!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);
const upload=multer({storage:multer.diskStorage({destination:uploadDir,filename:(r,f,cb)=>cb(null,Date.now()+'-'+f.originalname.replace(/[^a-zA-Z0-9._-]/g,'_'))}),limits:{fileSize:4*1024*1024}});
app.use(express.json()); app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET||'change-session-secret',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:7*24*60*60*1000}}));
app.use('/uploads',express.static(uploadDir)); app.use(express.static(__dirname));
function user(req,res,next){if(!req.session.user)return res.status(401).json({error:'Please log in first.'});next()}
function admin(req,res,next){if(!req.session.admin)return res.status(403).json({error:'Admin access required.'});next()}
app.post('/api/register',async(req,res)=>{try{const {full_name,location,contact,password}=req.body;if(!full_name||!location||!contact||!password||password.length<6)return res.status(400).json({error:'Please provide all details. Password must be at least 6 characters.'});const hash=await bcrypt.hash(password,12);const info=db.prepare('INSERT INTO users(full_name,location,contact,password_hash) VALUES(?,?,?,?)').run(full_name.trim(),location.trim(),contact.trim(),hash);req.session.user={id:info.lastInsertRowid,full_name:full_name.trim(),contact:contact.trim()};res.json({ok:true});}catch(e){res.status(400).json({error:e.message.includes('UNIQUE')?'That contact is already registered.':'Could not create account.'})}});
app.post('/api/login',async(req,res)=>{const {contact,password}=req.body;const u=db.prepare('SELECT * FROM users WHERE contact=?').get(contact);if(!u||!(await bcrypt.compare(password,u.password_hash)))return res.status(401).json({error:'Invalid contact or password.'});req.session.user={id:u.id,full_name:u.full_name,contact:u.contact};res.json({ok:true,user:req.session.user});});
app.post('/api/logout',(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/me',(req,res)=>res.json({user:req.session.user||null,admin:!!req.session.admin}));
app.get('/api/products',(req,res)=>res.json(db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all()));
app.post('/api/orders',user,(req,res)=>{try{const {items,location,payment_reference}=req.body;if(!Array.isArray(items)||!items.length)return res.status(400).json({error:'Your cart is empty.'});let total=0;const clean=items.map(i=>{const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(i.id);if(!p)throw new Error('A product is no longer available.');const qty=Math.max(1,parseInt(i.qty||1));total+=p.price*qty;return {id:p.id,name:p.name,price:p.price,qty};});const bulk=clean.reduce((n,i)=>n+i.qty,0)>=5;const info=db.prepare('INSERT INTO orders(user_id,customer_name,contact,location,total,payment_reference,items_json) VALUES(?,?,?,?,?,?,?)').run(req.session.user.id,req.session.user.full_name,req.session.user.contact,location||'Not provided',total,payment_reference||'',JSON.stringify(clean));
const order={id:info.lastInsertRowid,customer_name:req.session.user.full_name,contact:req.session.user.contact,location:location||'Not provided',total,payment_reference:payment_reference||'',items:clean,free_delivery:bulk};
notifyNewOrder(order).catch(err=>console.error('Order notification email failed:',err.message));
res.json({ok:true,order_id:info.lastInsertRowid,total,free_delivery:bulk});}catch(e){res.status(400).json({error:e.message})}});
app.get('/api/my-orders',user,(req,res)=>res.json(db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC').all(req.session.user.id)));
app.post('/api/admin/login',(req,res)=>{if(req.body.username===ADMIN_USER&&req.body.password===ADMIN_PASSWORD){req.session.admin=true;return res.json({ok:true})}res.status(401).json({error:'Invalid admin credentials.'})});
app.post('/api/admin/products',admin,upload.single('image'),(req,res)=>{const {name,description,price,unit}=req.body;if(!name||!price)return res.status(400).json({error:'Name and price are required.'});const image=req.file?'/uploads/'+req.file.filename:'';const info=db.prepare('INSERT INTO products(name,description,price,unit,image) VALUES(?,?,?,?,?)').run(name,description||'',parseInt(price),unit||'item',image);res.json({ok:true,id:info.lastInsertRowid})});
app.put('/api/admin/products/:id',admin,upload.single('image'),(req,res)=>{const old=db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id);if(!old)return res.status(404).json({error:'Not found'});const image=req.file?'/uploads/'+req.file.filename:old.image;db.prepare('UPDATE products SET name=?,description=?,price=?,unit=?,image=?,active=? WHERE id=?').run(req.body.name,req.body.description||'',parseInt(req.body.price),req.body.unit||'item',image,req.body.active==='0'?0:1,req.params.id);res.json({ok:true})});
app.delete('/api/admin/products/:id',admin,(req,res)=>{db.prepare('UPDATE products SET active=0 WHERE id=?').run(req.params.id);res.json({ok:true})});
app.get('/api/admin/orders',admin,(req,res)=>res.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all()));
app.patch('/api/admin/orders/:id',admin,(req,res)=>{db.prepare('UPDATE orders SET status=? WHERE id=?').run(req.body.status,req.params.id);res.json({ok:true})});
app.get('/api/admin/users',admin,(req,res)=>res.json(db.prepare('SELECT id,full_name,location,contact,created_at FROM users ORDER BY id DESC').all()));
app.get('/admin',(req,res)=>{if(!req.session.admin)return res.sendFile(path.join(__dirname,'admin-login.html'));res.sendFile(path.join(__dirname,'admin.html'))});
app.listen(PORT,()=>console.log(`GRACE INNOVATION PROJECT running on port ${PORT}`));
